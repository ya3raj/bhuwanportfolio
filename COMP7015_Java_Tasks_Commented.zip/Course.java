// Course class definition
public class Course {
    private int id = 1000;
    private double courseCredit = 3;
    private double courseCost = 1000.0;
    private String courseTitle;

    // Default constructor
    public Course() {}

    // Constructor with ID and Title
    public Course(int id, String courseTitle) {
        this.id = id;
        this.courseTitle = courseTitle;
    }

    // Setters
    public void setCourseCredit(double credit) {
        this.courseCredit = credit;
    }

    public void setCourseCost(double cost) {
        this.courseCost = cost;
    }

    // Getters
    public double getCourseCredit() {
        return courseCredit;
    }

    public double getCourseCost() {
        return courseCost;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    // Apply discount to course cost
    public void discountCourseCost(double discount) {
        if (discount > courseCost) {
            System.out.println("Discount can not exceed the course cost");
        } else {
            courseCost -= discount;
        }
    }
}