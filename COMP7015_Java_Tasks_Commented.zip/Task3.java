import java.util.Scanner;

// Task 3: Using Grade class
public class Task3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Get mark from user
        System.out.print("Enter the mark: ");
        double mark = input.nextDouble();

        // Create Grade object and print grade
        Grade grade = new Grade(mark);
        System.out.println("Grade: " + grade.getGrade());
    }
}