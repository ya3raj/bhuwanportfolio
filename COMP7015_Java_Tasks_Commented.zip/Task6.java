import java.util.Scanner;

// Task 6: Reverse an integer
public class Task6 {
    // Method to reverse digits
    public static int reverse(int number) {
        int reversed = 0;
        while (number != 0) {
            int digit = number % 10;
            reversed = reversed * 10 + digit;
            number /= 10;
        }
        return reversed;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Get number and display reversed
        System.out.print("Enter an integer: ");
        int number = input.nextInt();

        System.out.println("Reversed number: " + reverse(number));
    }
}