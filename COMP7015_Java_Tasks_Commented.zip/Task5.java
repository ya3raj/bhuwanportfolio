import java.util.Scanner;

// Task 5: Calculate circle area
public class Task5 {
    // Method to calculate area
    public static double calculateArea(double radius) {
        return radius * radius * 3.14;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Read radius
        System.out.print("Enter radius: ");
        double r = input.nextDouble();

        // Calculate and display area
        System.out.println("Area of circle: " + calculateArea(r));
    }
}