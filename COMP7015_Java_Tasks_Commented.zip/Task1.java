import java.util.Scanner;

// Task 1: Payroll Statement
public class Task1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Get employee details
        System.out.print("Enter employee's name: ");
        String name = input.nextLine();

        System.out.print("Enter number of hours worked in a week: ");
        double hours = input.nextDouble();

        System.out.print("Enter base hourly pay rate: ");
        double baseRate = input.nextDouble();

        System.out.print("Enter base tax rate: ");
        double baseTax = input.nextDouble();

        System.out.print("Enter overtime hourly pay rate: ");
        double overtimeRate = input.nextDouble();

        System.out.print("Enter overtime tax rate: ");
        double overtimeTax = input.nextDouble();

        double grossPay, tax;

        // If hours are less than or equal to 20, calculate normally
        if (hours <= 20) {
            grossPay = hours * baseRate;
            tax = grossPay * baseTax;
        } else {
            // Calculate base and overtime separately
            double baseHours = 20;
            double overtimeHours = hours - 20;
            grossPay = (baseHours * baseRate) + (overtimeHours * overtimeRate);
            tax = (baseHours * baseRate * baseTax) + (overtimeHours * overtimeRate * overtimeTax);
        }

        double netPay = grossPay - tax;

        // Output the results
        System.out.println("Employee Name: " + name);
        System.out.println("Hours Worked: " + hours);
        System.out.println("Pay Rate: $" + baseRate);
        System.out.println("Gross Pay: $" + grossPay);
        System.out.println("Tax: $" + tax);
        System.out.println("Net Pay: $" + netPay);
    }
}