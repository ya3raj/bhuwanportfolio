// Task 4: Create and modify Course object
public class Task4 {
    public static void main(String[] args) {
        // Create course object with details
        Course c = new Course(1122, "Introduction to programming");
        c.setCourseCredit(4);
        c.setCourseCost(3500.0);

        // Apply discount
        c.discountCourseCost(350.0);

        // Display final course details
        System.out.println("Course Title: " + c.getCourseTitle());
        System.out.println("Course Cost after discount: $" + c.getCourseCost());
    }
}