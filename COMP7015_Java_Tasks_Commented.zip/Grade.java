// Grade class definition
public class Grade {
    private double mark;

    // Constructor
    public Grade(double mark) {
        this.mark = mark;
    }

    // Method to return grade based on mark
    public String getGrade() {
        if (mark >= 85) return "High Distinction";
        else if (mark >= 75) return "Distinction";
        else if (mark >= 65) return "Credit";
        else if (mark >= 50) return "Pass";
        else return "Fail";
    }
}