import java.util.Scanner;

// Task 2: Convert integer to hexadecimal
public class Task2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Prompt user for integer input
        System.out.print("Enter an integer (0 - 127): ");
        int number = input.nextInt();

        // Validate and display hexadecimal
        if (number >= 0 && number <= 127) {
            System.out.println("Hex-decimal number: 0x" + Integer.toHexString(number).toUpperCase());
        } else {
            System.out.println("Error: Number must be between 0 and 127.");
        }
    }
}